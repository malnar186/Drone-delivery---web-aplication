<?php
include("zaglavlje.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>IWA iwa_2022_vz_projekt</title>
		<meta name="autor" content="Jan Malnar"/>
		<meta name="datum" content="20.06.2023."/>
		<meta charset="utf-8"/>
		<link rel="stylesheet" type="text/css"
			   href="css\style.css"/>
	</head>
	<body>
<table class="tablicakorisnika">
	<caption>O autoru</caption>
<tr>
      <td colspan="2">
      <img src="slike/slika.jpeg" alt="oautoru" width="300px" height="400px">
      </td>
			<td>
      <ul>
				<li>Ime: Jan</li>
				<li>Prezime: Malnar</li>
				<li>JMBAG: 0016149145</li>
				<li>E-mail: jmalnar20@student.foi.hr</li>
				<li>Centar: Varaždin</li>
				<li>Godina prvog upisa: 2022/2023.</li>
			</ul>
      </td>

    </tr>
</table>
	</body>
</html>