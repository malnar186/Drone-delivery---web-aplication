<?php include("zaglavlje.php"); 
$bp=spojiSeNaBazu();
?>

<?php 
$sql="SELECT dostava_id,korisnik_id,dron_id,datum_vrijeme_dostave, datum_vrijeme_zahtjeva, opis_posiljke, adresa_dostave,
adresa_polazista, dostavaKM, dostavaKG, hitnost, ukupna_cijena, napomene, status	
  FROM dostava
  ORDER BY hitnost DESC"; 


$rs=izvrsiUpit($bp,$sql);




echo "<table class='tablicakorisnika'>";
echo "<caption>Zahtjevi za dostavom</caption>";
echo "<thead><tr>
  <th>ID dostave</th>
  <th>Datum i vrijeme dostave</th>
  <th>Datum i vrijeme zahtjeva</th>
  <th>Opis pošiljke</th>
  <th>Napomene</th>
  <th>Adresa polazišta</th>
  <th>Adresa dostave</th>
  <th>Dostava u KM</th>
  <th>Dostava u KG</th>
  <th>Hitnost</th>
  <th>Ukupna cijena</th>
  <th>Status</th>
  <th class='izbrisi'></th>";
echo "</tr></thead>";

while ($row = mysqli_fetch_array($rs)) {
  $dostava_id=$row['dostava_id'];
  $korisnik_id=$row['korisnik_id'];
  $dron_id=$row['dron_id'];
  $datum_vrijeme_dostave= $row['datum_vrijeme_dostave'];
  $datum_vrijeme_zahtjeva = $row['datum_vrijeme_zahtjeva'];
  $opis_posiljke = $row['opis_posiljke'];
  $napomene = $row['napomene'];
  $adresa_polazista = $row['adresa_polazista'];
  $adresa_dostave = $row['adresa_dostave'];
  $dostavaKM= $row['dostavaKM'];
  $dostavaKG = $row['dostavaKG'];
  $hitnost = $row['hitnost'];
  $ukupna_cijena = $row['ukupna_cijena'];
  $status = $row['status'];

  echo "<tbody>";
  if($aktivni_korisnik_id == $korisnik_id && $aktivni_korisnik_tip==2) {
    
    echo "
    <tr><td>$dostava_id</td>
     <td>$datum_vrijeme_dostave</td>
     <td>$datum_vrijeme_zahtjeva</td>
     <td>$opis_posiljke</td>
     <td>$napomene</td>
     <td>$adresa_polazista</td>
     <td>$adresa_dostave</td>
     <td>$dostavaKM</td>
     <td>$dostavaKG</td>
     <td>$hitnost</td>
     <td>$ukupna_cijena</td>
     <td>$status</td></tr>";
     
    
  }elseif($aktivni_korisnik_tip==1 || $aktivni_korisnik_tip==0){
    
    echo "
    <tr><td>$dostava_id</td>
     <td>$datum_vrijeme_dostave</td>
     <td>$datum_vrijeme_zahtjeva</td>
     <td>$opis_posiljke</td>
     <td>$napomene</td>
     <td>$adresa_polazista</td>
     <td>$adresa_dostave</td>
     <td>$dostavaKM</td>
     <td>$dostavaKG</td>
     <td>$hitnost</td>
     <td>$ukupna_cijena</td>
     <td>$status</td>
     <td>
     <input class='gumb' type='submit' name='submit' value='Potvrdi'/>
     
     </td></tr>";
     
    
  }
  if(isset($_POST['submit']));
}
echo "</tbody>";
echo "</table>";



?>

<?php zatvoriVezuNaBazu($bp) ?>